<?php

namespace App\Http\Controllers;

use App\Http\Requests\UserUpdateRequest;
use App\User;
use Illuminate\Contracts\Support\Renderable;
use Illuminate\Support\Facades\Gate;
use Illuminate\Support\Facades\Storage;

class HomeController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     *
     * @return Renderable
     */
    public function index()
    {
        $user = auth()->user();

        return view('home', compact('user'));
    }

    public function update(UserUpdateRequest $request, User $user)
    {
        $response = Gate::inspect('update', $user);

        if ($response->allowed()) {
            if ($request->hasFile('photo')){
                Storage::delete($user->photo);
            }
            $user->update($request->validated());
            return back()->with([
                'class' => 'success',
                'status' => "Se Modificó Correctamente.",
            ]);
        }
        return back()->with([
            'class' => 'danger',
            'status' => $response->message(),
        ]);
    }

    public function delete(User $user)
    {
        $response = Gate::inspect('forceDelete', $user);
        $photo = $user->photo;
        if ($user->forceDelete()) {
            Storage::delete($photo);
            auth()->logout();
        }
        return back()->with([
            'class' => 'danger',
            'status' => $response->message(),
        ]);
    }
}
