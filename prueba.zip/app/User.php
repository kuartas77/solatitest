<?php

namespace App;

use Illuminate\Contracts\Auth\MustVerifyEmail;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
use Illuminate\Http\UploadedFile;

class User extends Authenticatable
{
    use Notifiable;

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'name', 'email', 'password','photo',
        'identification_number','type_identification','years',
        'favorite_language','years_experience'
    ];

    /**
     * The attributes that should be hidden for arrays.
     *
     * @var array
     */
    protected $hidden = [
        'password', 'remember_token',
    ];

    /**
     * The attributes that should be cast to native types.
     *
     * @var array
     */
    protected $casts = [
        'email_verified_at' => 'datetime',
    ];

    public function setPasswordAttribute($value)
    {
        if (!is_null($value)){
            //si tiene un password lo encripta
            $this->attributes['password'] = bcrypt($value);
        }
    }

    public function setPhotoAttribute($value)
    {
        if ($value instanceof UploadedFile){
            //se guarda el archivo en la carpeta /storage/app/profile_photo
            //el nombre se asigna automaticamente
            $this->attributes['photo'] = $value->store("profile_photo");
        }
    }
}
