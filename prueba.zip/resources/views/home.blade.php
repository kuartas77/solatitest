@extends('layouts.app')

@section('content')
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header">{{ __('messages.Update User') }}</div>

                    <div class="card-body">
                        @if (session('status'))
                            <div class="alert alert-{{ session('class') }}" role="alert">
                                {{ session('status') }}
                            </div>
                        @endif

                        <form method="POST" action="{{ route('user.update',[$user->id]) }}"
                              enctype="multipart/form-data">
                            @csrf
                            @method('PUT')


                            <div class="form-group row">
                                <label for="name" class="col-md-4 col-form-label text-md-right">{{ __('messages.Name') }}</label>

                                <div class="col-md-6">
                                    <input id="name" type="text"
                                           class="form-control @error('name') is-invalid @enderror" name="name"
                                           value="{{ $user->name }}" required autocomplete="name" autofocus>

                                    @error('name')
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $message }}</strong>
                                    </span>
                                    @enderror
                                </div>
                            </div>

                            <div class="form-group row">
                                <label for="email"
                                       class="col-md-4 col-form-label text-md-right">{{ __('messages.E-Mail Address') }}</label>

                                <div class="col-md-6">
                                    <input id="email" type="email"
                                           class="form-control @error('email') is-invalid @enderror" name="email"
                                           value="{{$user->email }}" required autocomplete="email">

                                    @error('email')
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $message }}</strong>
                                    </span>
                                    @enderror
                                </div>
                            </div>

                            <div class="form-group row">
                                <label for="password"
                                       class="col-md-4 col-form-label text-md-right">{{ __('messages.Password') }}</label>

                                <div class="col-md-6">
                                    <input id="password" type="password"
                                           class="form-control @error('password') is-invalid @enderror" name="password"
                                           autocomplete="new-password">

                                    @error('password')
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $message }}</strong>
                                    </span>
                                    @enderror
                                </div>
                            </div>

                            <div class="form-group row">
                                <label for="password-confirm"
                                       class="col-md-4 col-form-label text-md-right">{{ __('messages.Confirm Password') }}</label>

                                <div class="col-md-6">
                                    <input id="password-confirm" type="password" class="form-control"
                                           name="password_confirmation" autocomplete="new-password">
                                </div>
                            </div>

                            <div class="form-group row">
                                <label for="identification_number"
                                       class="col-md-4 col-form-label text-md-right">{{ __('messages.identification_number') }}</label>

                                <div class="col-md-6">
                                    <input id="identification_number" type="text"
                                           class="form-control @error('identification_number') is-invalid @enderror"
                                           value="{{ $user->identification_number }}" name="identification_number"
                                           required>

                                    @error('identification_number')
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $message }}</strong>
                                    </span>
                                    @enderror
                                </div>
                            </div>

                            <div class="form-group row">
                                <label for="type_identification"
                                       class="col-md-4 col-form-label text-md-right">{{ __('messages.type_identification') }}</label>

                                <div class="col-md-6">
                                    <select name="type_identification" id="type_identification"
                                            class="form-control @error('type_identification') is-invalid @enderror"
                                            value="{{ $user->type_identification }}" required>
                                        <option value="CC" selected>CC</option>
                                        <option value="CE">CE</option>
                                        <option value="TI">TI</option>
                                    </select>
                                    @error('type_identification')
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $message }}</strong>
                                    </span>
                                    @enderror
                                </div>
                            </div>

                            <div class="form-group row">
                                <label for="years"
                                       class="col-md-4 col-form-label text-md-right">{{ __('messages.years') }}</label>

                                <div class="col-md-6">
                                    <input id="years" type="text"
                                           class="form-control @error('years') is-invalid @enderror" name="years"
                                           value="{{ $user->years }}" required>

                                    @error('years')
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $message }}</strong>
                                    </span>
                                    @enderror
                                </div>
                            </div>

                            <div class="form-group row">
                                <label for="favorite_language"
                                       class="col-md-4 col-form-label text-md-right">{{ __('messages.favorite_language') }}</label>

                                <div class="col-md-6">
                                    <input id="type_identification" type="text"
                                           class="form-control @error('favorite_language') is-invalid @enderror"
                                           value="{{ $user->favorite_language }}" name="favorite_language" required>

                                    @error('favorite_language')
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $message }}</strong>
                                    </span>
                                    @enderror
                                </div>
                            </div>

                            <div class="form-group row">
                                <label for="years_experience"
                                       class="col-md-4 col-form-label text-md-right">{{ __('messages.years_experience') }}</label>

                                <div class="col-md-6">
                                    <input id="years_experience" type="text"
                                           class="form-control @error('years_experience') is-invalid @enderror"
                                           value="{{ $user->years_experience }}" name="years_experience" required>

                                    @error('years_experience')
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $message }}</strong>
                                    </span>
                                    @enderror
                                </div>
                            </div>

                            <div class="form-group row">
                                <label for="photo"
                                       class="col-md-4 col-form-label text-md-right">{{ __('messages.photo') }}</label>

                                <div class="col-md-6">
                                    <input id="photo" type="file"
                                           class="form-control @error('photo') is-invalid @enderror" name="photo">

                                    @error('photo')
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $message }}</strong>
                                    </span>
                                    @enderror
                                </div>
                            </div>

                            <div class="form-group row mb-0">
                                <div class="col-md-6 offset-md-4">
                                    <button type="submit" class="btn btn-primary">
                                        {{ __('messages.Update') }}
                                    </button>
                                    <button type="button" class="btn btn-danger"
                                            onclick="alertDeleteUser()">{{__('messages.Delete')}}</button>
                                </div>
                            </div>
                        </form>
                        <form method="POST" action="{{route('user.delete', [$user->id])}}" class="d-none"
                              id="delete-form">
                            @csrf
                            @method('DELETE')
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection
@section('scripts')
    <script>
        function alertDeleteUser() {
            swal.fire({
                title: '{{__('messages.sure')}}',
                text: '{{__('messages.no_revert_this')}}',
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#3085d6',
                cancelButtonColor: '#d33',
                confirmButtonText: '{{__('messages.confirm_delete')}}'
            }).then((result) => {
                if (result.isConfirmed) {
                    document.getElementById('delete-form').submit();
                }

            })
        }
    </script>
@endsection
