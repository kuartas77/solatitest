<?php
return [
    'Update User' => 'Modificar Usuario',
    'Name' => 'Nombre',
    'E-Mail Address' => 'Correo',
    'Password' => 'Contraseña',
    'Confirm Password' => 'Confirmar Contraseña',
    'identification_number' => 'Número de Identificación',
    'type_identification' => 'Tipo De Identificación',
    'years' => 'Años',
    'favorite_language' => 'Lenguaje De Programacion Favorito',
    'years_experience' => 'Años De Experiencia',
    'photo' => 'Foto',
    'Update' => 'Modificar',
    'Delete' => 'Eliminar',

    'sure' => 'Estas Segur@',
    'no_revert_this'=> '¡No podrás revertir esto!',
    'confirm_delete'=> '¡Sí, bórralo!'
];
